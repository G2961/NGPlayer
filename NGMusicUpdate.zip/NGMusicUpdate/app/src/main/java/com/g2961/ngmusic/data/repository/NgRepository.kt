package com.g2961.ngmusic.data.repository

import com.g2961.ngmusic.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URLEncoder

class NgRepository {

    private val baseUrl = "https://www.newgrounds.com"
    private val userAgent =
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36"

    // ─── Публичные методы ─────────────────────────────────────────────────────

    suspend fun getFeaturedTracks(): List<Track> =
        parseTracks("$baseUrl/audio/featured")

    suspend fun getBrowseTracks(offset: Int = 0): List<Track> =
        parseTracks("$baseUrl/audio/browse?offset=$offset&inner=1")

    suspend fun getPopularTracks(offset: Int = 0): List<Track> =
        parseTracks("$baseUrl/audio/popular?offset=$offset&inner=1")

    suspend fun searchTracks(query: String, offset: Int = 0): List<Track> {
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        // NG поиск: /search/conduct/audio?terms=...  (первая страница)
        // при offset > 0 используем API-эндпоинт с параметром page
        val page = offset / 24 + 1
        val url = if (page == 1)
            "$baseUrl/search/conduct/audio?terms=$q"
        else
            "$baseUrl/search/conduct/audio?terms=$q&page=$page"
        return parseTracks(url)
    }

    /**
     * Получаем URL mp3 двумя способами:
     * 1. og:audio на странице /audio/listen/{id}
     * 2. Если не нашли — строим URL вручную через audio.ngfiles.com
     */
    suspend fun getMp3Url(track: Track): String? = withContext(Dispatchers.IO) {
        // Сначала пробуем страницу трека
        runCatching {
            val doc = connect("$baseUrl/audio/listen/${track.id}")
            doc.selectFirst("meta[property=og:audio]")?.attr("content")
                ?.takeIf { it.isNotBlank() }
        }.getOrNull()
        // Если не нашли — строим из audio.ngfiles.com (работает даже без разрешения на скачивание)
            ?: buildAudioUrl(track)
    }

    /**
     * Строим mp3 URL из audio.ngfiles.com:
     * https://audio.ngfiles.com/{floor(id/1000)*1000}/{id}_{slug}.mp3
     * Slug берём из og:url или title со страницы.
     */
    private suspend fun buildAudioUrl(track: Track): String? = withContext(Dispatchers.IO) {
        runCatching {
            val numId = track.id.toLongOrNull() ?: return@runCatching null
            val folder = (numId / 1000) * 1000

            // Пробуем получить slug с og:url
            val doc = connect("$baseUrl/audio/listen/${track.id}")
            val ogUrl = doc.selectFirst("meta[property=og:url]")?.attr("content") ?: ""
            // og:url вида https://www.newgrounds.com/audio/listen/1570039/rewind
            val slug = ogUrl.trimEnd('/').substringAfterLast('/').takeIf { it != track.id }
                ?: slugify(track.title)

            "https://audio.ngfiles.com/$folder/${track.id}_$slug.mp3"
        }.getOrNull()
    }

    // ─── Парсинг ──────────────────────────────────────────────────────────────

    private suspend fun parseTracks(url: String): List<Track> = withContext(Dispatchers.IO) {
        runCatching {
            val doc = connect(url)
            parseItems(doc)
        }.getOrElse {
            it.printStackTrace()
            emptyList()
        }
    }

    private fun parseItems(doc: Document): List<Track> {
        // Основной список — li[data-hub-id]
        val items = doc.select("li[data-hub-id]")

        return items.mapNotNull { li ->
            val id = li.attr("data-hub-id").takeIf { it.isNotBlank() } ?: return@mapNotNull null

            val playEl = li.selectFirst("[data-audio-duration]") ?: li.selectFirst("[data-hub-id]")

            val title = (li.selectFirst("h4.item-title")
                ?: li.selectFirst("h4")
                ?: li.selectFirst(".title"))?.text()?.trim()
                ?: return@mapNotNull null

            val artist = (li.selectFirst("strong")
                ?: li.selectFirst(".item-details-main strong")
                ?: li.selectFirst(".detail-author"))?.text()?.trim() ?: ""

            // Жанр / тип: "Song - Techno" или просто "Song"
            val genreEl = li.selectFirst(".detail-description")
                ?: li.selectFirst(".genre")
                ?: li.selectFirst(".item-details-secondary")
            val genre = genreEl?.text()?.trim() ?: ""

            // Длительность
            val duration = (playEl?.attr("data-audio-duration")
                ?: li.attr("data-audio-duration"))
                .toIntOrNull() ?: 0

            val audioType = (playEl?.attr("data-audio-type")
                ?: li.attr("data-audio-type"))
                .toIntOrNull() ?: 3

            // Иконка — строим aicon URL из id (высокое качество)
            val numId = id.toLongOrNull()
            val iconUrl = if (numId != null) {
                val folder = numId / 1000
                "https://aicon.ngfiles.com/$folder/${id}_raw.png"
            } else {
                li.selectFirst("img")?.attr("src") ?: ""
            }

            Track(
                id = id,
                title = title,
                artist = artist,
                genre = genre,
                iconUrl = iconUrl,
                duration = duration,
                audioType = audioType
            )
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun connect(url: String): Document =
        Jsoup.connect(url)
            .userAgent(userAgent)
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .timeout(20_000)
            .get()

    /** "My Cool Song!" -> "my-cool-song" — для fallback audio URL */
    private fun slugify(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-z0-9\\s-]"), "")
            .replace(Regex("\\s+"), "-")
            .trim('-')
}
