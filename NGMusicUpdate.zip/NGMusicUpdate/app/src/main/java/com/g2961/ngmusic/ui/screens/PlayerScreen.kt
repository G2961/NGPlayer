package com.g2961.ngmusic.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.g2961.ngmusic.MainViewModel
import com.g2961.ngmusic.ui.theme.*
import com.g2961.ngmusic.util.TrackDownloader
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val track by viewModel.currentTrack.collectAsState()
    val isPlaying by viewModel.player.isPlaying.collectAsState()
    val duration by viewModel.player.duration.collectAsState()
    val isLoadingTrack by viewModel.isLoadingTrack.collectAsState()
    val context = LocalContext.current

    var position by remember { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var downloadDone by remember { mutableStateOf(false) }

    // Обновление позиции каждые 500мс
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            if (!isSeeking) {
                position = viewModel.player.getCurrentPosition()
            }
            delay(500)
        }
    }

    // Сброс при смене трека
    LaunchedEffect(track?.id) {
        position = 0L
        downloadDone = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NgBgDark)
    ) {
        // ── Топбар ────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NgBgDeep)
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back",
                    tint = NgTextPrimary)
            }
            Text(
                text = "Now Playing",
                color = NgTextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f)
            )
            // Кнопка скачивания
            IconButton(
                onClick = {
                    val mp3 = track?.mp3Url
                    if (mp3 != null && track != null) {
                        TrackDownloader.download(context, track!!, mp3)
                        downloadDone = true
                    }
                },
                enabled = track?.mp3Url != null
            ) {
                Icon(
                    imageVector = if (downloadDone) Icons.Default.DownloadDone else Icons.Default.Download,
                    contentDescription = "Download",
                    tint = if (downloadDone) NgGreen else if (track?.mp3Url != null) NgOrange else NgTextDim
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))

            // ── Обложка диска ─────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(NgBgElevated, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = track?.iconUrl,
                    contentDescription = track?.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                )
                // Центральное "отверстие диска"
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(NgBgDark, CircleShape)
                )
            }

            Spacer(Modifier.height(28.dp))

            // ── Мета ─────────────────────────────────────────────────────────
            Text(
                text = track?.title ?: "—",
                color = NgOrange,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 28.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = track?.artist ?: "—",
                color = NgTextPrimary,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
            )
            if (!track?.genre.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = track?.genre ?: "",
                    color = NgTextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(28.dp))

            // ── Прогресс ──────────────────────────────────────────────────────
            if (duration > 0) {
                Slider(
                    value = position.coerceIn(0L, duration).toFloat(),
                    onValueChange = {
                        isSeeking = true
                        position = it.toLong()
                    },
                    onValueChangeFinished = {
                        viewModel.player.seekTo(position)
                        isSeeking = false
                    },
                    valueRange = 0f..duration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = NgOrange,
                        activeTrackColor = NgOrange,
                        inactiveTrackColor = NgBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatDuration((position / 1000).toInt()),
                        color = NgTextMuted, fontSize = 12.sp
                    )
                    Text(
                        text = formatDuration((duration / 1000).toInt()),
                        color = NgTextMuted, fontSize = 12.sp
                    )
                }
            } else if (isLoadingTrack) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = NgOrange,
                    trackColor = NgBorder
                )
            }

            Spacer(Modifier.height(20.dp))

            // ── Контролы ──────────────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Предыдущий
                IconButton(
                    onClick = { viewModel.playPrev() },
                    enabled = viewModel.hasPrev(),
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(
                        Icons.Default.SkipPrevious,
                        contentDescription = "Previous",
                        tint = if (viewModel.hasPrev()) NgTextPrimary else NgTextDim,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Play / Pause
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(NgOrange, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoadingTrack) {
                        CircularProgressIndicator(
                            color = Color.Black,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        IconButton(
                            onClick = { viewModel.player.togglePlayPause() },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }
                }

                // Следующий
                IconButton(
                    onClick = { viewModel.playNext() },
                    enabled = viewModel.hasNext(),
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(
                        Icons.Default.SkipNext,
                        contentDescription = "Next",
                        tint = if (viewModel.hasNext()) NgTextPrimary else NgTextDim,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Ссылка на NG
            track?.let {
                TextButton(onClick = { /* TODO: открыть в браузере */ }) {
                    Text(
                        text = "newgrounds.com/audio/listen/${it.id}",
                        color = NgTextDim,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
