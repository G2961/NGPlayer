package com.g2961.ngmusic

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.g2961.ngmusic.data.model.Track
import com.g2961.ngmusic.data.repository.NgRepository
import com.g2961.ngmusic.player.PlaybackService
import com.g2961.ngmusic.player.PlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class TabType { FEATURED, BROWSE, POPULAR, SEARCH }

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = NgRepository()

    init {
        // Запускаем сервис — он держит ExoPlayer и MediaSession (уведомление)
        val ctx = app.applicationContext
        ctx.startForegroundService(Intent(ctx, PlaybackService::class.java))
    }

    // PlayerController подключается к сервису через MediaController
    val player = PlayerController(app.applicationContext)

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _isLoadingMore = MutableStateFlow(false)
    val isLoadingMore: StateFlow<Boolean> = _isLoadingMore

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack

    private val _isLoadingTrack = MutableStateFlow(false)
    val isLoadingTrack: StateFlow<Boolean> = _isLoadingTrack

    private val PAGE_SIZE = 24
    private var currentOffset = 0
    private var currentTab = TabType.FEATURED
    private var currentQuery = ""
    private var hasMore = true

    init {
        loadFeatured()
    }

    fun loadFeatured() {
        currentTab = TabType.FEATURED; currentOffset = 0; hasMore = false
        loadTracks(reset = true) { repository.getFeaturedTracks() }
    }

    fun loadBrowse() {
        currentTab = TabType.BROWSE; currentOffset = 0; hasMore = true
        loadTracks(reset = true) { repository.getBrowseTracks(0) }
    }

    fun loadPopular() {
        currentTab = TabType.POPULAR; currentOffset = 0; hasMore = true
        loadTracks(reset = true) { repository.getPopularTracks(0) }
    }

    fun search(query: String) {
        if (query.isBlank()) { loadFeatured(); return }
        currentTab = TabType.SEARCH; currentQuery = query; currentOffset = 0; hasMore = true
        loadTracks(reset = true) { repository.searchTracks(query, 0) }
    }

    fun loadMore() {
        if (_isLoadingMore.value || !hasMore) return
        currentOffset += PAGE_SIZE
        viewModelScope.launch {
            _isLoadingMore.value = true
            runCatching {
                val new = when (currentTab) {
                    TabType.BROWSE   -> repository.getBrowseTracks(currentOffset)
                    TabType.POPULAR  -> repository.getPopularTracks(currentOffset)
                    TabType.SEARCH   -> repository.searchTracks(currentQuery, currentOffset)
                    TabType.FEATURED -> emptyList()
                }
                if (new.isEmpty()) hasMore = false else _tracks.value = _tracks.value + new
            }.onFailure { _error.value = "Ошибка загрузки: ${it.message}" }
            _isLoadingMore.value = false
        }
    }

    fun playTrack(track: Track) {
        viewModelScope.launch {
            _currentTrack.value = track
            _isLoadingTrack.value = true
            runCatching {
                if (track.mp3Url == null) track.mp3Url = repository.getMp3Url(track)
                track.mp3Url?.let {
                    player.play(url = it, title = track.title, artist = track.artist, artworkUri = track.aIconUrl)
                } ?: run { _error.value = "Не удалось найти ссылку на трек" }
            }.onFailure { _error.value = "Ошибка воспроизведения: ${it.message}" }
            _isLoadingTrack.value = false
        }
    }

    fun playNext() {
        val list = _tracks.value
        val idx = list.indexOfFirst { it.id == _currentTrack.value?.id }
        if (idx != -1 && idx + 1 < list.size) playTrack(list[idx + 1])
        else if (idx + 1 >= list.size) loadMore()
    }

    fun playPrev() {
        val list = _tracks.value
        val idx = list.indexOfFirst { it.id == _currentTrack.value?.id }
        if (idx > 0) playTrack(list[idx - 1])
    }

    fun hasPrev(): Boolean = _tracks.value.indexOfFirst { it.id == _currentTrack.value?.id } > 0

    fun hasNext(): Boolean {
        val list = _tracks.value
        val idx = list.indexOfFirst { it.id == _currentTrack.value?.id }
        return idx != -1 && idx + 1 < list.size
    }

    private fun loadTracks(reset: Boolean = false, fetch: suspend () -> List<Track>) {
        viewModelScope.launch {
            if (reset) { _isLoading.value = true; _error.value = null; _tracks.value = emptyList() }
            runCatching { _tracks.value = fetch() }
                .onFailure { _error.value = "Ошибка загрузки: ${it.message}" }
            _isLoading.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        player.release()
    }
}
