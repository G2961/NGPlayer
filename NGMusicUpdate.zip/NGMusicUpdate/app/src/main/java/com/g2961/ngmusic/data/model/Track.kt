package com.g2961.ngmusic.data.model

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val iconUrl: String,
    val duration: Int,       // секунды
    val audioType: Int,
    var mp3Url: String? = null
) {
    /** https://aicon.ngfiles.com/{id/1000}/{id}_raw.png */
    val aIconUrl: String get() {
        val numId = id.toLongOrNull() ?: return iconUrl
        val folder = numId / 1000
        return "https://aicon.ngfiles.com/$folder/${id}_raw.png"
    }

    /** https://audio.ngfiles.com/{floor(id/1000)*1000}/{id}_*.mp3  —  папка кратна 1000 */
    val audioBaseUrl: String get() {
        val numId = id.toLongOrNull() ?: return ""
        val folder = (numId / 1000) * 1000
        return "https://audio.ngfiles.com/$folder/"
    }
}
