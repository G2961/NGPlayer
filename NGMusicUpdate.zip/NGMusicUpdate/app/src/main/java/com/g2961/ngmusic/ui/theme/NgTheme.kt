package com.g2961.ngmusic.ui.theme

import androidx.compose.ui.graphics.Color

// ── Основная палитра Newgrounds ──────────────────────────────────────────────
val NgOrange       = Color(0xFFFF6600)   // основной акцент
val NgOrangeLight  = Color(0xFFFF8833)   // hover / secondary accent
val NgYellow       = Color(0xFFFFCC00)   // NG "звёздный" жёлтый

// ── Фоны ─────────────────────────────────────────────────────────────────────
val NgBgDeep       = Color(0xFF000000)   // чёрная шапка / топбар
val NgBgDark       = Color(0xFF111111)   // основной фон
val NgBgCard       = Color(0xFF1A1A1A)   // карточка трека
val NgBgElevated   = Color(0xFF222222)   // слегка приподнятый слой (поиск)

// ── Границы ──────────────────────────────────────────────────────────────────
val NgBorder       = Color(0xFF333333)
val NgBorderLight  = Color(0xFF444444)

// ── Текст ────────────────────────────────────────────────────────────────────
val NgTextPrimary  = Color(0xFFFFFFFF)
val NgTextMuted    = Color(0xFF888888)
val NgTextDim      = Color(0xFF555555)

// ── Прочее ───────────────────────────────────────────────────────────────────
val NgRed          = Color(0xFFCC0000)   // ошибка / 18+
val NgGreen        = Color(0xFF33CC33)   // успех / скачано
