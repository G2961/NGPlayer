package com.g2961.ngmusic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.g2961.ngmusic.MainViewModel
import com.g2961.ngmusic.TabType
import com.g2961.ngmusic.data.model.Track
import com.g2961.ngmusic.ui.theme.*

@Composable
fun HubScreen(
    viewModel: MainViewModel,
    onTrackClick: (Track) -> Unit,
    onMiniPlayerClick: () -> Unit
) {
    val tracks by viewModel.tracks.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isLoadingMore by viewModel.isLoadingMore.collectAsState()
    val error by viewModel.error.collectAsState()
    val currentTrack by viewModel.currentTrack.collectAsState()
    val isPlaying by viewModel.player.isPlaying.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val keyboard = LocalSoftwareKeyboardController.current

    // Подгрузка при достижении конца списка
    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisible >= total - 4
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadMore()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NgBgDark)
    ) {
        // ── Шапка ────────────────────────────────────────────────────────────
        NgTopBar()

        // ── Поиск ────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NgBgDeep)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search audio...", color = NgTextMuted, fontSize = 14.sp) },
                modifier = Modifier.weight(1f).height(48.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NgOrange,
                    unfocusedBorderColor = NgBorder,
                    focusedContainerColor = NgBgElevated,
                    unfocusedContainerColor = NgBgElevated,
                    focusedTextColor = NgTextPrimary,
                    unfocusedTextColor = NgTextPrimary,
                    cursorColor = NgOrange
                ),
                shape = RoundedCornerShape(4.dp),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    keyboard?.hide()
                    viewModel.search(searchQuery)
                    selectedTab = -1
                }),
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null,
                        tint = NgTextMuted, modifier = Modifier.size(18.dp))
                },
                trailingIcon = if (searchQuery.isNotEmpty()) {{
                    IconButton(onClick = {
                        searchQuery = ""
                        viewModel.loadFeatured()
                        selectedTab = 0
                    }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear",
                            tint = NgTextMuted, modifier = Modifier.size(16.dp))
                    }
                }} else null
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    keyboard?.hide()
                    viewModel.search(searchQuery)
                    selectedTab = -1
                },
                colors = ButtonDefaults.buttonColors(containerColor = NgOrange),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("Go!", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        }

        // ── Табы ─────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NgBgDeep)
        ) {
            listOf("Featured", "Browse", "Popular").forEachIndexed { i, label ->
                val active = selectedTab == i
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            selectedTab = i
                            searchQuery = ""
                            when (i) {
                                0 -> viewModel.loadFeatured()
                                1 -> viewModel.loadBrowse()
                                2 -> viewModel.loadPopular()
                            }
                        }
                        .background(if (active) NgOrange else Color.Transparent)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (active) Color.Black else NgTextMuted,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        HorizontalDivider(color = NgBorder, thickness = 1.dp)

        // ── Контент ───────────────────────────────────────────────────────────
        Box(modifier = Modifier.weight(1f)) {
            when {
                isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NgOrange, strokeWidth = 2.dp)
                }
                error != null && tracks.isEmpty() -> Box(
                    Modifier.fillMaxSize(), contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Warning, contentDescription = null,
                            tint = NgRed, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(8.dp))
                        Text(error ?: "", color = NgRed, fontSize = 13.sp)
                    }
                }
                else -> LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    items(tracks, key = { it.id }) { track ->
                        TrackItem(
                            track = track,
                            isActive = currentTrack?.id == track.id,
                            isPlaying = isPlaying && currentTrack?.id == track.id,
                            onClick = { onTrackClick(track) }
                        )
                    }
                    if (isLoadingMore) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    color = NgOrange, strokeWidth = 2.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ── Мини-плеер ────────────────────────────────────────────────────────
        currentTrack?.let { track ->
            MiniPlayer(
                track = track,
                isPlaying = isPlaying,
                onToggle = { viewModel.player.togglePlayPause() },
                onClick = onMiniPlayerClick
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun NgTopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NgBgDeep)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = "NG",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = NgOrange
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = "Audio Portal",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NgTextMuted,
                modifier = Modifier.padding(bottom = 3.dp)
            )
        }
        // NG логотип-звезда (упрощённо)
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(NgOrange, RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("★", color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun TrackItem(
    track: Track,
    isActive: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (isActive) NgBgElevated else NgBgCard)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Обложка — круглая
        Box(modifier = Modifier.size(52.dp)) {
            AsyncImage(
                model = track.iconUrl,
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(NgBgElevated, CircleShape)
            )
            // Мини-индикатор воспроизведения
            if (isActive) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.VolumeUp else Icons.Default.Pause,
                        contentDescription = null,
                        tint = NgOrange,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (isActive) NgOrange else NgOrange,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.artist,
                color = NgTextPrimary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (track.genre.isNotBlank()) {
                Text(
                    text = track.genre,
                    color = NgTextMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(Modifier.width(8.dp))

        Text(
            text = formatDuration(track.duration),
            color = NgTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
    HorizontalDivider(color = NgBorder, thickness = 0.5.dp)
}

@Composable
private fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    onToggle: () -> Unit,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NgBgDeep)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = track.iconUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(NgBgElevated, CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = NgOrange,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.artist,
                color = NgTextMuted,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
        IconButton(onClick = onToggle) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = NgOrange,
                modifier = Modifier.size(28.dp)
            )
        }
    }
    HorizontalDivider(color = NgBorder, thickness = 1.dp)
}

fun formatDuration(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%d:%02d".format(m, s)
}
