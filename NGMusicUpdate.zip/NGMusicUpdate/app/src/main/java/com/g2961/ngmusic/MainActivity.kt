package com.g2961.ngmusic

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import com.g2961.ngmusic.player.PlaybackService
import com.g2961.ngmusic.ui.screens.HubScreen
import com.g2961.ngmusic.ui.screens.PlayerScreen
import com.g2961.ngmusic.ui.theme.NGMusicTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Стартуем сервис заранее — к моменту первого нажатия Play
        // MediaController уже будет подключён
        startForegroundService(Intent(this, PlaybackService::class.java))

        setContent {
            NGMusicTheme {
                NgMusicApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NgMusicApp(viewModel: MainViewModel) {
    var showPlayer by remember { mutableStateOf(false) }

    BackHandler(enabled = showPlayer) {
        showPlayer = false
    }

    if (showPlayer) {
        PlayerScreen(
            viewModel = viewModel,
            onBack = { showPlayer = false }
        )
    } else {
        HubScreen(
            viewModel = viewModel,
            onTrackClick = { track ->
                viewModel.playTrack(track)
                showPlayer = true
            },
            onMiniPlayerClick = { showPlayer = true }
        )
    }
}
