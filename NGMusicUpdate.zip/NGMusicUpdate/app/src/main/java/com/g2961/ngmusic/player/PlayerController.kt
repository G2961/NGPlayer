package com.g2961.ngmusic.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Тонкая обёртка над MediaController.
 * Подключается к PlaybackService и предоставляет те же StateFlow,
 * что раньше давал MusicPlayer — все экраны остаются без изменений.
 */
class PlayerController(context: Context) {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration

    private val _trackEnded = MutableStateFlow(false)
    val trackEnded: StateFlow<Boolean> = _trackEnded

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_READY -> {
                    _duration.value = controller?.duration?.coerceAtLeast(0L) ?: 0L
                    _trackEnded.value = false
                }
                Player.STATE_ENDED -> {
                    _trackEnded.value = true
                }
                else -> {}
            }
        }
    }

    init {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, PlaybackService::class.java)
        )
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(listener)
        }, MoreExecutors.directExecutor())
    }

    fun play(url: String, title: String = "", artist: String = "", artworkUri: String? = null) {
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .apply { artworkUri?.let { setArtworkUri(android.net.Uri.parse(it)) } }
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(url)
            .setMediaMetadata(meta)
            .build()

        controller?.run {
            setMediaItem(mediaItem)
            prepare()
            play()
        }
        _trackEnded.value = false
    }

    fun togglePlayPause() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun getCurrentPosition(): Long = controller?.currentPosition ?: 0L

    fun release() {
        controller?.removeListener(listener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
    }
}
