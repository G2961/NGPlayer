package com.g2961.ngmusic.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.g2961.ngmusic.data.model.Track

object TrackDownloader {

    fun download(context: Context, track: Track, mp3Url: String) {
        val fileName = "${track.artist} - ${track.title}.mp3"
            .replace(Regex("[/\\\\:*?\"<>|]"), "_") // sanitize

        val request = DownloadManager.Request(Uri.parse(mp3Url))
            .setTitle(track.title)
            .setDescription(track.artist)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "NGMusic/$fileName")
            .setMimeType("audio/mpeg")
            .addRequestHeader(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
            )

        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
    }
}
